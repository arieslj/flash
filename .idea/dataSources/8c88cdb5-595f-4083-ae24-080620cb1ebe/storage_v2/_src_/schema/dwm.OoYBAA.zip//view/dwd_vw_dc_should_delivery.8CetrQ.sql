create view dwd_vw_dc_should_delivery as
SELECT `store_id`
     , `stat_date`
     , `pno`
     , `state`
     , `ruler`
     , `hour`
     , `delivery_flag`
     , `arrival_scan_route_at`
     , `last_route_marker_category`
     , `is_pri_package`
     , `express_category`
     , `client_id`
     , `store_delivery_frequency`
     , `handover_scan_route_at`
     , `extra`
     , `vehicle_time`
     , `detain_client_modify_date`
     , `agt_prod`.`month`(`agt_prod`.`curdate`()) `m_date`
FROM `bi_pro`.`dc_should_delivery_2022_07`
;

